#ifndef ECN_H
#define ECN_H

#define ECN_CE 1
#define ECN_CWR 2
#define ECN_ECHO 4

#endif
