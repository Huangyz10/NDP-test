#include "eth_pause_packet.h"

PacketDB<EthPausePacket> EthPausePacket::_packetdb;

