#!/bin/sh
./run_ndp_collateral.sh
./run_dctcp_collateral.sh
./run_dctcp_collateral_lossless.sh