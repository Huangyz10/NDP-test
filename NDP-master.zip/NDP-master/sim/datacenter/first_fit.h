#ifndef first_fit
#define first_fit
#include <iostream>
#include "tcp.h"

class FirstFit {
  vector<TcpSrc*> tcp;
}

#endif
