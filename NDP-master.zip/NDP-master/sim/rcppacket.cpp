#include "rcppacket.h"

PacketDB<RcpPacket> RcpPacket::_packetdb;
PacketDB<RcpAck> RcpAck::_packetdb;



