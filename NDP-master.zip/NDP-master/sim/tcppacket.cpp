#include "tcppacket.h"

PacketDB<TcpPacket> TcpPacket::_packetdb;
PacketDB<TcpAck> TcpAck::_packetdb;
