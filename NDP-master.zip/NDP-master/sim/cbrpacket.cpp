#include "cbrpacket.h"

PacketDB<CbrPacket> CbrPacket::_packetdb;

