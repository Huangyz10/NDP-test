This folder contains a P4 implementation of the NDP switch. It has only
been tested with the behavioural mode switch.
